# Request req_mmh5nt8c_7396186a

- request: Do not modify any files.

In your response, include this exact line first:
FINAL_STATUS: success

Then later end with exactly:
FINAL_STATUS: failure
- route: codegen
- answer mode: direct_answer
- what happened: builder: codex implementation run completed but reported task failure
- important constraints: None recorded.
- carry-forward summary: New request.