# Request req_mmgl5o1r_9183502e

- request: Write a command-based intake subsystem using TalonFX.
- route: codegen
- answer mode: direct_answer
- what happened: builder: builder completed a test run
- important constraints: None recorded.
- carry-forward summary: New request.